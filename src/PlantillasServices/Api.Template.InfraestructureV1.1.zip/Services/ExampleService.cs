﻿using Template.Core.Contracts.Repositories;
using Template.Core.Contracts.Services;
using Template.Core.Exceptions;
using Template.Core.Objects.DbTypes;
using Template.Core.Objects.Dtos;
using $safeprojectname$.Models.UnitOfWorks;

namespace $safeprojectname$.Services
{
    public class ExampleService : IExampleService
    {
        private IExampleRepository _exampleRepository;
        private IUnitOfWork _unitOfWork;

        public ExampleService(IExampleRepository exampleRepository, IUnitOfWork unitOfWork) 
        {
            _exampleRepository = exampleRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> CreateValue(ValueDto value)
        {            
            if(value == null)  throw new ExampleException();

            var result = await _exampleRepository.CreateValue(new ValueEntity(value.Value1, value.Value2));
            _unitOfWork.Confirm();

            return result;
        }

        public async Task<IList<ValueDto>> GetValues()
        {
            var result = await _exampleRepository.GetValues();

            var values = result
                .Select(value => new ValueDto {

                    Value1 = value.Value1,
                    Value2 = value.Value2,
                }).ToList();

            return values;
        }
    }
}
