﻿using Template.Core.Contracts.Repositories;
using Template.Core.Objects.DbTypes;
using $safeprojectname$.Models.DbAuthentication;
using $safeprojectname$.Models.UnitOfWorks;

namespace $safeprojectname$.Repositories
{
    public class ExampleRepository : IExampleRepository
    {
        private readonly DbExampleContext _dbcontext;
        private readonly IUnitOfWork _unitOfWork;

        public ExampleRepository(DbExampleContext dbcontext, IUnitOfWork unitOfWork) 
        {
            _dbcontext = dbcontext;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> CreateValue(ValueEntity accessTokenEntity)
        {
            var result = await _dbcontext.SpCreateValueAsync(accessTokenEntity);
            await _unitOfWork.ConfirmAsync();
            return result;
        }

        public async Task<IList<ValueEntity>> GetValues()
        {
            return await _dbcontext.SpGetValueAsync();
        }
    }
}
