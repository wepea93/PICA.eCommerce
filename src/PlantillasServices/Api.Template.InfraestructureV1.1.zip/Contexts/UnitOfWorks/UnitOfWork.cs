﻿using $safeprojectname$.Models.DbAuthentication;

namespace $safeprojectname$.Models.UnitOfWorks
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DbExampleContext _dbContext;

        public UnitOfWork(DbExampleContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void Confirm()
        {
            _dbContext.SaveChanges();
        }

        public async Task ConfirmAsync()
        {
            await _dbContext.SaveChangesAsync();
        }
    }
}
