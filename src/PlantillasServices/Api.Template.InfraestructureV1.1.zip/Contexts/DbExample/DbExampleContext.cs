﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using Template.Core.Config;
using Template.Core.Objects.DbTypes;

namespace $safeprojectname$.Models.DbAuthentication
{
    public partial class DbExampleContext : DbContext
    {
        private string _spCreateValue { get; set; } = AppConfiguration.Configuration["AppConfiguration:DataBases:DataBase1:StoreProcedures:SpCreateValue"].ToString();
        private string _spGetValue { get; set; } = AppConfiguration.Configuration["AppConfiguration:DataBases:DataBase1:StoreProcedures:SpGetValues"].ToString();

        public DbExampleContext(DbContextOptions<DbExampleContext> options) : base(options) { }

        public virtual DbSet<ValueEntity> ValueEntity { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }

        public async Task<bool> SpCreateValueAsync(ValueEntity valueEntity)
        {
            var result = await this.Database.ExecuteSqlRawAsync($"EXEC {_spCreateValue} @userName, @token, @expiresAt",
                new SqlParameter("@value1", valueEntity.Value1),
                new SqlParameter("@value2", valueEntity.Value2));

            return result > 0;
        }

        public async Task<IList<ValueEntity>> SpGetValueAsync()
        {
            var result = await this.Set<ValueEntity>().FromSqlInterpolated($"{_spGetValue}").ToListAsync();
            return result != null && result.Any() ? result.ToList() : null;
        }

    }
}
