﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Template.Core.Contracts.Services;
using Template.Core.Objects.Dtos;
using Template.Core.Objects.Request;
using Template.Core.Objects.Responses;
using WebApiProducts.Config;

namespace WebApiAuthorizer.Controllers
{
    [AuthorizationFilter]
    [Route("api/[controller]")]
    [ApiController]
    public class ExampleController : ControllerBase
    {
        private readonly ILogger<ExampleController> _logger;
        private IExampleService _exampleService;

        public ExampleController(IExampleService exampleService, ILogger<ExampleController> logger) 
        {
            _exampleService = exampleService;
            _logger = logger;
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("ExampleMethod")]
        public async Task<ActionResult<ServiceResponse<ValueResponse>>> CreateValue([FromBody] ValueRequest request) 
        {
            var businessObject = new ValueDto(request.UserName, request.Password);
            var result = await _exampleService.CreateValue(businessObject);
            var response = new ValueResponse(result);

            var message = "Esto es una prueba: {@messageDetail}";
            var messageDetail = new { message1 = "msg1", message2 = "msg2"};

            _logger.LogInformation(message, messageDetail);
            _logger.LogWarning(message, messageDetail);
            _logger.LogError(message, messageDetail);
            return Ok(new ServiceResponse<ValueResponse>("Operación exitosa", response));
        }
    }
}
