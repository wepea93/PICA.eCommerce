﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Objects.DbTypes
{
    public class ValueEntity
    {
        [Key]
        public string Value1 { get; set; }
        public string Value2 { get; set; }

        public ValueEntity(string Value1, string Value2)
        {
            Value1 = Value1;
            Value2 = Value2;
        }

        public ValueEntity() { }
    }
}
