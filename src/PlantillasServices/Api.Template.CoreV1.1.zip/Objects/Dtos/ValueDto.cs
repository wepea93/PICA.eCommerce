﻿
namespace $safeprojectname$.Objects.Dtos
{
    public class ValueDto
    {
        public string Value1 { get; set; }
        public string Value2 { get; set; }

        public ValueDto(string Value1, string Value2)
        {
            Value1 = Value1;
            Value2 = Value2;
        }

        public ValueDto() { }
    }
}
