﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Objects.Request
{
    public  class ValueRequest
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
