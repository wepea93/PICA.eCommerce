﻿
namespace $safeprojectname$.Helpers.Mappers
{
    public class MapperHelper : IMapperHelper
    {
    }
}
