﻿
namespace $safeprojectname$.Helpers.Mappers
{
    public interface IMapperHelper
    {
    }
}
