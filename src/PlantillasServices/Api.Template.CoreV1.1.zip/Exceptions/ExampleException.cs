﻿
namespace $safeprojectname$.Exceptions
{
    public class ExampleException : Exception
    {
        public ExampleException() 
            : base("Mensaje de error.") { }
    }
}
