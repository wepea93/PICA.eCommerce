﻿using $safeprojectname$.Objects.DbTypes;

namespace $safeprojectname$.Contracts.Repositories
{
    public interface IExampleRepository
    {
        Task<bool> CreateValue(ValueEntity accessTokenEntity);
        Task<IList<ValueEntity>> GetValues();
    }
}
