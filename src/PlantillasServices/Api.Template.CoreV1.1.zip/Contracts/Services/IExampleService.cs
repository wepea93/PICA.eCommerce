﻿using $safeprojectname$.Objects.Dtos;

namespace $safeprojectname$.Contracts.Services
{
    public interface IExampleService
    {
        Task<bool> CreateValue(ValueDto value);
        Task<IList<ValueDto>> GetValues();
    }
}
